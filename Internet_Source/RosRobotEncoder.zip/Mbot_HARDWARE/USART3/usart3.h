#ifndef __USRAT3_H
#define __USRAT3_H 

#include "stm32f10x.h"	  	
#include <stdio.h>

void usart3_init(uint32_t bound);

#endif

